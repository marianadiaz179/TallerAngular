import { Component, OnInit } from '@angular/core';
import { Serie } from './serie';
import { SerieService } from './serie.service';

@Component({
  selector: 'app-serie',
  templateUrl: './serie.component.html',
  styleUrls: ['./serie.component.css'],
})
export class SerieComponent implements OnInit {
  series: Array<Serie> = [];
  constructor(private serieService: SerieService) {}

  public promedio: number = 0;

  getSeries() : void{
    this.serieService.getSeries().subscribe((series) => {
      this.series = series;
      this.getAvg();
    });
  }

  getAvg() {
    for (let i of this.series) {
      this.promedio += i.seasons;
    }

    this.promedio = this.promedio / this.series.length;
  }

  ngOnInit() {
    this.getSeries();
    //this.getAvg();
  }
}
